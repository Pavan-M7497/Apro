import type { Metadata, Viewport } from 'next'
import { DM_Sans, Playfair_Display } from 'next/font/google'
import { Analytics } from '@vercel/analytics/next'
import { Toaster } from 'react-hot-toast'
import { LocationProvider } from '@/components/location-context'
import { AuthProvider } from '@/components/auth-context'
import { Header } from '@/components/layout/header'
import { Footer } from '@/components/layout/footer'
import { WhatsAppButton } from '@/components/whatsapp-button'
import './globals.css'

const dmSans = DM_Sans({ 
  subsets: ["latin"],
  variable: '--font-dm-sans',
  display: 'swap',
})

const playfair = Playfair_Display({ 
  subsets: ["latin"],
  variable: '--font-playfair',
  display: 'swap',
})

export const metadata: Metadata = {
  title: '154 Breakfast Club | Premium Brunch Experience in Bangalore',
  description: 'Experience the art of slow coffee and premium brunch at 154 Breakfast Club. Three distinctive locations in Indiranagar, Koramangala & HSR Layout crafting unforgettable moments.',
  keywords: ['brunch bangalore', 'breakfast cafe', 'coffee shop indiranagar', 'koramangala cafe', 'HSR Layout brunch', 'premium dining bangalore', 'avocado toast', 'specialty coffee'],
  openGraph: {
    title: '154 Breakfast Club | Premium Brunch Experience in Bangalore',
    description: 'Experience the art of slow coffee and premium brunch at 154 Breakfast Club in Bangalore.',
    type: 'website',
  },
}

export const viewport: Viewport = {
  themeColor: '#FAF7F2',
  width: 'device-width',
  initialScale: 1,
}

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode
}>) {
  return (
    <html lang="en" className={`${dmSans.variable} ${playfair.variable} bg-background`}>
      <body className="font-sans antialiased bg-background text-foreground">
        <AuthProvider>
          <LocationProvider>
            <Toaster
              position="top-center"
              toastOptions={{
                style: {
                  background: '#2C1810',
                  color: '#FAF7F2',
                  borderRadius: '12px',
                },
              }}
            />
            <Header />
            <main>{children}</main>
            <Footer />
            <WhatsAppButton />
          </LocationProvider>
        </AuthProvider>
        {process.env.NODE_ENV === 'production' && <Analytics />}
      </body>
    </html>
  )
}
